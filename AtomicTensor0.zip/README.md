# TensorFramework
A atomic, multi-backend, easy deeplearning framework

## 设计目标
原子化的、多后端加速的、易于使用的深度学习框架


算子 张量 分离
第一期使用 numpy numba  
第二期添加 cuda xtensor mars

Tensor
Opetator
Layer
Module
Loss
Optim
Model

# 记录
1. demo

# 下一步
分离算子